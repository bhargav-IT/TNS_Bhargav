package Day11_Animal;

abstract class Animal {
	abstract void cat();
	abstract void dog();
}
