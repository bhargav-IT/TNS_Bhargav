package Day9_Final_Abstract;

public class MainCal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Addition add = new Addition();
		add.showResult();
		
		Subtraction sub = new Subtraction();
		sub.showResult();
		
		Multiplication mul = new Multiplication();
		mul.showResult();
		
		Division div = new Division();
		div.showResult();
	}

}
