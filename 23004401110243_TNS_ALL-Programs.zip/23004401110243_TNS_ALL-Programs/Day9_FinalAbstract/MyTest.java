package Day9_Final_Abstract;

public abstract class MyTest {
	public void calculate(){
		System.out.println("Calculation");
	}
	
	public abstract void showResult();
}
