package Day6_inheritance;

public class ChildClass extends ParentClass{

}
