package Day10_Bank_Activity;

public interface Age {
	int age = 21;
	
	void printdata();
}
