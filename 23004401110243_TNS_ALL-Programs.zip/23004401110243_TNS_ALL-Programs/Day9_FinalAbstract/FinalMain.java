package Day9_Final_Abstract;

public class FinalMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     FinalDemo f = new FinalDemo();
	   f.setRadius(50);   
	   f.display();
	 }
	}
